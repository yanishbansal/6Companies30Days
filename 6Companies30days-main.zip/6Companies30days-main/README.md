# 6Companies30days

## This repo will contain codes/notes of my this challenge let's go 
